require 'puppetlabs_spec_helper/module_spec_helper'

class Undef
  def inspect
    'undef'
  end
end
