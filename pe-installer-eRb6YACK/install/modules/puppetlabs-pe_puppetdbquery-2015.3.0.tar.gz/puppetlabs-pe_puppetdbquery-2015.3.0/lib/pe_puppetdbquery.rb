module PePuppetDBQuery
  # Current version of this module
  VERSION = [2, 0, 2]
end
