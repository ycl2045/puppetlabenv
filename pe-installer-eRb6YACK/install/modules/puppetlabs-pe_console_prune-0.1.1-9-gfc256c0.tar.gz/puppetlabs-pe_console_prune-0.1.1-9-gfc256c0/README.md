This is a puppet module to install a cron job that will 
run the reports:prune rake task on your Puppet Enterprise Console.  
